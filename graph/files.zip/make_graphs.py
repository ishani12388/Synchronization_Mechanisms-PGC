import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

threads = [1, 2, 4, 8]
none     = [0.0287, 0.0291, 0.0334, 0.0358]
critical = [0.1451, 0.3268, 0.8096, 0.7698]
atomic   = [0.0636, 0.2016, 0.3760, 0.3549]
lock     = [0.1495, 0.6072, 1.5182, 1.2284]
none_count = [10000000, 5759937, 2445382, 1621211]
N = 10000000

# Graph 1: execution time vs threads (line)
plt.figure(figsize=(8, 5))
plt.plot(threads, none, "o-", label="None (race)", color="tab:red")
plt.plot(threads, critical, "s-", label="Critical", color="tab:orange")
plt.plot(threads, atomic, "^-", label="Atomic", color="tab:green")
plt.plot(threads, lock, "d-", label="Lock", color="tab:blue")
plt.xticks(threads)
plt.xlabel("Number of threads")
plt.ylabel("Execution time (seconds)")
plt.title("Execution Time vs Number of Threads (10,000,000 increments)")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("graph1_time_vs_threads.png", dpi=150)
plt.close()

# Graph 2: grouped bar chart of time
x = np.arange(len(threads))
w = 0.2
plt.figure(figsize=(9, 5))
plt.bar(x - 1.5*w, none, w, label="None (race)", color="tab:red")
plt.bar(x - 0.5*w, critical, w, label="Critical", color="tab:orange")
plt.bar(x + 0.5*w, atomic, w, label="Atomic", color="tab:green")
plt.bar(x + 1.5*w, lock, w, label="Lock", color="tab:blue")
plt.xticks(x, [str(t) for t in threads])
plt.xlabel("Number of threads")
plt.ylabel("Execution time (seconds)")
plt.title("Time Comparison of Synchronization Mechanisms")
plt.grid(axis="y", alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("graph2_time_bar_comparison.png", dpi=150)
plt.close()

# Graph 3: correctness of the unsynchronized version
plt.figure(figsize=(8, 5))
bars = plt.bar([str(t) for t in threads], none_count, color="tab:red")
plt.axhline(N, color="green", linestyle="--", label="Expected = 10,000,000")
for b, c in zip(bars, none_count):
    plt.text(b.get_x() + b.get_width()/2, c + 150000, f"{c:,}", ha="center", fontsize=9)
plt.xlabel("Number of threads")
plt.ylabel("Final counter value")
plt.title("Race Condition: Final Count with No Synchronization")
plt.ylim(0, N * 1.15)
plt.legend()
plt.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig("graph3_race_correctness.png", dpi=150)
plt.close()

# Graph 4: slowdown relative to atomic at each thread count
plt.figure(figsize=(8, 5))
plt.plot(threads, [c/a for c, a in zip(critical, atomic)], "s-", label="Critical / Atomic", color="tab:orange")
plt.plot(threads, [l/a for l, a in zip(lock, atomic)], "d-", label="Lock / Atomic", color="tab:blue")
plt.axhline(1, color="gray", linestyle="--")
plt.xticks(threads)
plt.xlabel("Number of threads")
plt.ylabel("Time relative to Atomic (x times slower)")
plt.title("How Much Slower Are Critical and Lock Than Atomic?")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("graph4_slowdown_vs_atomic.png", dpi=150)
plt.close()
print("done")
